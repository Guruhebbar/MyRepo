import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponentComponent } from './home-component/home-component.component';

const routes: Routes = [{ path: 'home/:appid', component: HomeComponentComponent },
{ path: 'home', redirectTo: 'home/1' },
//{ path: 'home/:appid', redirectTo: 'home/1/1' },
{ path: '', redirectTo: 'home/1', pathMatch: 'full' }];

@NgModule({
  imports: [RouterModule.forRoot(routes,
    { enableTracing: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
