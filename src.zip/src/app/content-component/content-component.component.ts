import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';
import { LinkServiceService } from '../link-service.service';

@Component({
  selector: 'app-content-component',
  templateUrl: './content-component.component.html',
  styleUrls: ['./content-component.component.css']
})
export class ContentComponentComponent implements OnInit {
  appid: number;
  id: number;
  private sub: any;
  links: number;
  subscription: Subscription;
  constructor(private route: ActivatedRoute,private linkServiceService: LinkServiceService) { 
    this.subscription = this.linkServiceService.getLink().subscribe(link => {
      if (link) {
        this.links = link;
        this.ngOnInit();
      }
    });
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.appid = +params["appid"];
      this.id = this.links;
   });

   console.log("content page : "+this.id);
 }

 ngOnDestroy() {
   this.sub.unsubscribe();
   this.subscription.unsubscribe();
 }

}
