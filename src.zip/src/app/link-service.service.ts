import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LinkServiceService {
  private subject = new Subject<number>();

  constructor() { }  
  
      sendLink(link: number) {
          this.subject.next(link);
      }
  
      clearLink() {
          this.subject.next();
      }
  
      getLink(): Observable<number> {
          return this.subject.asObservable();
      }
}
