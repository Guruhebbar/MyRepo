import { Component, OnInit } from '@angular/core';
import { Ng2CarouselamosModule } from 'ng2-carouselamos';
import { LinkServiceService } from '../link-service.service';

@Component({
  selector: 'app-menu-component',
  templateUrl: './menu-component.component.html',
  styleUrls: ['./menu-component.component.css'],
})
export class MenuComponentComponent implements OnInit {

  images: Array<any> = []
  appid: number;
  id: number;
  private sub: any;
  constructor(private linkServiceService: LinkServiceService) {
    this.images = [
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_query_builder_white_18dp.png',
      'assets/img/round_query_builder_white_18dp.png',
      'assets/img/round_query_builder_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
      'assets/img/round_language_white_18dp.png',
    ];
  }
  
  ngOnInit() {
    
 }

 sendLink(menuId): void {
  // send message to subscribers via observable subject
  this.linkServiceService.sendLink(menuId);
  var loadele = document.getElementById("vertical-menu").children;
  var i;
  for (i = 0; i < loadele.length; i++) {
    loadele[i].classList.remove("active");
  }

  loadele[0].className += " active";
}

clearLink(): void {
  // clear messages
  this.linkServiceService.clearLink();
}

 
}