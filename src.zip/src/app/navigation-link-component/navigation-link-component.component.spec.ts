import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavigationLinkComponentComponent } from './navigation-link-component.component';

describe('NavigationLinkComponentComponent', () => {
  let component: NavigationLinkComponentComponent;
  let fixture: ComponentFixture<NavigationLinkComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavigationLinkComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavigationLinkComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
