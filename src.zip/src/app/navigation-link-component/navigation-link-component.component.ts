import { Component, OnInit,AfterViewInit } from '@angular/core';
import { ActivatedRoute,RouterModule } from '@angular/router';
import { LinkServiceService } from '../link-service.service';

@Component({
  selector: 'app-navigation-link-component',
  templateUrl: './navigation-link-component.component.html',
  styleUrls: ['./navigation-link-component.component.css']
})
export class NavigationLinkComponentComponent implements OnInit {
  menuLinkArr = [];
  id: number;
  private sub: any;
  constructor(private route: ActivatedRoute,private linkServiceService: LinkServiceService) { }

  ngOnInit() {
    this.menuLinkArr = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
    this.sub = this.route.params.subscribe(params => {
      this.id = +params["appid"]; 
      this.linkServiceService.sendLink(1);
   });
   console.log("nav page app id: "+this.id);
   
 }

 ngAfterViewInit(){
  var loadele = document.getElementById("vertical-menu").children;
  var i;
  for (i = 0; i < loadele.length; i++) {
    loadele[i].classList.remove("active");
  }
  loadele[0].className += " active";
 }
 
 sendLink(menuId,$event): void {
   console.log("test : ",$event);
  // send message to subscribers via observable subject
  this.linkServiceService.sendLink(menuId); 

  let clickedElement = $event.target || $event.srcElement;
  
      if( clickedElement.nodeName === "SPAN" ) {
  
        let isCertainButtonAlreadyActive = clickedElement.parentElement.querySelector(".active");
        // if a Button already has Class: .active
        if( isCertainButtonAlreadyActive ) {
          isCertainButtonAlreadyActive.classList.remove("active");
        }
  
        clickedElement.className += " active";
      }
  
}

clearLink(): void {
  // clear messages
  this.linkServiceService.clearLink();
}

 ngOnDestroy() {
   this.sub.unsubscribe();
 }

}
